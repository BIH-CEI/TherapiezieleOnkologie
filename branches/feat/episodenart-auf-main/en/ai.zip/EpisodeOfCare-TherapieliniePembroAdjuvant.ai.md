# Therapielinie 3 – adjuvante Immuntherapie (Pembrolizumab), ambulant - Implementierungsleitfaden Therapieziele Onkologie v1.0.0-ballot

## Example EpisodeOfCare: Therapielinie 3 – adjuvante Immuntherapie (Pembrolizumab), ambulant

-------

**English**

-------

Profile: [Onkologische Behandlungsepisode](StructureDefinition-onko-behandlungsepisode.md)

> **Onkologische Therapieintention (Extension)**
* hauptintention: Adjuvant - intent
* phase: Maintenance antineoplastic therapy

**EnLiST-Linien-Segment (Extension)**: `https://bih-cei.de/fhir/therapieziele-onkologie/sid/enlist-line`/mamma-baumann-elot-1

**EnLiST-Zählstatus (Extension)**: Zählt in der LoT-Zählung

**Therapielinie – Medikationsverordnung (Extension)**: [MedicationRequest: extension = Same LoT; status = active; intent = plan; category = Tumor board Consult note; medication[x] = ](MedicationRequest-MedicationRequestPembroAdjuvantMamma.md)

**Behandlungsmodalität (Extension)**: Ambulante adjuvante Immuntherapie – Pembrolizumab-Monotherapie

**status**: Active

**type**: Systemische Therapielinie

### Diagnoses

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Condition** | **Role** | **Rank** |
| * | [Condition Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse](Condition-ConditionMamma.md) | Chief complaint | 1 |

**patient**: [Sabine Baumann Female, DoB: 1977-06-24](Patient-PatientinMamma.md)

**managingOrganization**: [Organization Zertifiziertes Brustzentrum Musterklinik](Organization-Tumorboard.md)

**period**: 2026-04-24 --> (ongoing)

**careManager**: [Practitioner Katrin Musterarzt ](Practitioner-OnkologinMamma.md)



## Resource Content

```json
{
  "resourceType" : "EpisodeOfCare",
  "id" : "TherapieliniePembroAdjuvant",
  "meta" : {
    "profile" : ["https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-behandlungsepisode"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "hauptintention",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "373846009",
          "display" : "Adjuvant - intent"
        }]
      }
    },
    {
      "url" : "phase",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "1345242003",
          "display" : "Maintenance antineoplastic therapy"
        }]
      }
    }],
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent"
  },
  {
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/enlist-line-segment",
    "valueIdentifier" : {
      "system" : "https://bih-cei.de/fhir/therapieziele-onkologie/sid/enlist-line",
      "value" : "mamma-baumann-elot-1"
    }
  },
  {
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/enlist-countable",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://bih-cei.de/fhir/therapieziele-onkologie/CodeSystem/enlist-countable",
        "code" : "counted",
        "display" : "Zählt in der LoT-Zählung"
      }]
    }
  },
  {
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-line-medication-request",
    "valueReference" : {
      "reference" : "MedicationRequest/MedicationRequestPembroAdjuvantMamma"
    }
  },
  {
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-modalitaet",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "76334006",
        "display" : "Immunological therapy"
      }],
      "text" : "Ambulante adjuvante Immuntherapie – Pembrolizumab-Monotherapie"
    }
  }],
  "status" : "active",
  "type" : [{
    "coding" : [{
      "system" : "https://bih-cei.de/fhir/therapieziele-onkologie/CodeSystem/episodenart",
      "code" : "systemische-therapielinie",
      "display" : "Systemische Therapielinie"
    }]
  }],
  "diagnosis" : [{
    "condition" : {
      "reference" : "Condition/ConditionMamma"
    },
    "role" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
        "code" : "CC",
        "display" : "Chief complaint"
      }]
    },
    "rank" : 1
  }],
  "patient" : {
    "reference" : "Patient/PatientinMamma"
  },
  "managingOrganization" : {
    "reference" : "Organization/Tumorboard"
  },
  "period" : {
    "start" : "2026-04-24"
  },
  "careManager" : {
    "reference" : "Practitioner/OnkologinMamma"
  }
}

```

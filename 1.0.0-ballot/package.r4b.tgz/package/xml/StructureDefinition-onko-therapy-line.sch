<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile EpisodeOfCare
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:EpisodeOfCare</sch:title>
    <sch:rule context="f:EpisodeOfCare">
      <sch:assert test="count(f:extension[@url = 'https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent']) &gt;= 1">extension with URL = 'https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent']) &lt;= 1">extension with URL = 'https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:diagnosis) &gt;= 1">diagnosis: minimum cardinality of 'diagnosis' is 1</sch:assert>
      <sch:assert test="count(f:period) &gt;= 1">period: minimum cardinality of 'period' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:EpisodeOfCare/f:diagnosis</sch:title>
    <sch:rule context="f:EpisodeOfCare/f:diagnosis">
      <sch:assert test="count(f:role) &gt;= 1">role: minimum cardinality of 'role' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>

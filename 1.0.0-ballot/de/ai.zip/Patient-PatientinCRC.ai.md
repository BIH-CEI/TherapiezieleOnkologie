# Patientin – mCRC (Beispiel) - Implementierungsleitfaden Therapieziele Onkologie v1.0.0-ballot

## Beispiel Patient: Patientin – mCRC (Beispiel)

-------

**German**

-------

Erika Musterfrau Female, DoB: 1961-09-12

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "PatientinCRC",
  "name" : [{
    "family" : "Musterfrau",
    "given" : ["Erika"]
  }],
  "gender" : "female",
  "birthDate" : "1961-09-12"
}

```

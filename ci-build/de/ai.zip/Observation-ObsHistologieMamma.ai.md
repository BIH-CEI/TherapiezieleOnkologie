# Histologie / Morphologie (ICD-O-3, Beispiel) - Implementierungsleitfaden Therapieziele Onkologie v0.1.0

## Beispiel Observation: Histologie / Morphologie (ICD-O-3, Beispiel)

-------

**German**

-------

**status**: Final

**code**: Histology type in Cancer specimen Narrative

**subject**: [Sabine Baumann Female, DoB: 1977-06-24](Patient-PatientinMamma.md)

**effective**: 2025-09-15

**value**: Invasives Mammakarzinom, NST (ICD-O-3 8500/3)

**specimen**: [Specimen: status = available; type = Tissue specimen (specimen)](Specimen-SpecimenBiopsieMamma.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ObsHistologieMamma",
  "status" : "final",
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "33731-1",
      "display" : "Histology type in Cancer specimen Narrative"
    }]
  },
  "subject" : {
    "reference" : "Patient/PatientinMamma"
  },
  "effectiveDateTime" : "2025-09-15",
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "urn:oid:2.16.840.1.113883.6.43.1",
      "code" : "8500/3",
      "display" : "Invasives duktales Karzinom / Karzinom ohne speziellen Typ (NST)"
    }],
    "text" : "Invasives Mammakarzinom, NST (ICD-O-3 8500/3)"
  },
  "specimen" : {
    "reference" : "Specimen/SpecimenBiopsieMamma"
  }
}

```

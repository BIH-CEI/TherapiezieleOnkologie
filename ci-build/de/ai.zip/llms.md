# de.bih-cei.therapieziele-onkologie#0.1.0: Implementierungsleitfaden Therapieziele Onkologie(de)

## Pages

* [Startseite](index.md)
* [Anwendungsbeispiel (mCRC palliativ)](szenario-crc.md)
* [Anwendungsbeispiel (Mammakarzinom neoadjuvant)](szenario-mamma.md)
* [Analysebericht (LG-01)](analysebericht.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Artefaktübersicht](artifacts.md)

## Resources

### CodeSystems

* [Onkologische Therapieziel-Art](CodeSystem-onko-therapy-goal-type.md)
* [Onkologische Therapieintention](CodeSystem-onko-therapy-intent.md)

### ValueSets

* [Onkologische Therapieziel-Art (VS)](ValueSet-onko-therapy-goal-type.md)
* [Onkologische Therapieintention (VS)](ValueSet-onko-therapy-intent.md)

### Resource Profiles

* [Onkologischer CarePlan](StructureDefinition-onko-care-plan.md)
* [Onkologische Diagnose (Condition)](StructureDefinition-onko-condition.md)
* [Diagnostischer CarePlan](StructureDefinition-onko-diagnostic-care-plan.md)
* [Onkologisches Therapieziel](StructureDefinition-onko-therapy-goal.md)
* [Onkologische Therapielinie](StructureDefinition-onko-therapy-line.md)
* [Tumorboard MedicationRequest](StructureDefinition-onko-tumorboard-medication-request.md)
* [Tumorboard ServiceRequest](StructureDefinition-onko-tumorboard-service-request.md)

### Extensions

* [CarePlan Custodian (Extension)](StructureDefinition-onko-careplan-custodian.md)
* [Onkologische Therapieintention (Extension)](StructureDefinition-onko-therapy-intent.md)

### ImplementationGuides

* [Implementierungsleitfaden Therapieziele Onkologie](ImplementationGuide-bih-cei-therapieziele-onkologie.md)

### Examples

* [CarePlanCRCPalliativ (CarePlan)](CarePlan-CarePlanCRCPalliativ.md)
* [CarePlanMammaDiagnostik (CarePlan)](CarePlan-CarePlanMammaDiagnostik.md)
* [CarePlanMammaNeoadjuvant (CarePlan)](CarePlan-CarePlanMammaNeoadjuvant.md)
* [DiagnostikCarePlanCRC (CarePlan)](CarePlan-DiagnostikCarePlanCRC.md)
* [Interdisziplinäres Tumorboard Kolorektales Karzinom (CareTeam)](CareTeam-TumorboardCRC.md)
* [ConditionCRC (Condition)](Condition-ConditionCRC.md)
* [ConditionMamma (Condition)](Condition-ConditionMamma.md)
* [DiagnosticReportHistologieCRC (DiagnosticReport)](DiagnosticReport-DiagnosticReportHistologieCRC.md)
* [TherapielinieCRCErstlinie (EpisodeOfCare)](EpisodeOfCare-TherapielinieCRCErstlinie.md)
* [TherapielinieMammaNeoadjuvant (EpisodeOfCare)](EpisodeOfCare-TherapielinieMammaNeoadjuvant.md)
* [TherapiezielCRCKurativAbgelehnt (Goal)](Goal-TherapiezielCRCKurativAbgelehnt.md)
* [TherapiezielCRCLebensverlaengerung (Goal)](Goal-TherapiezielCRCLebensverlaengerung.md)
* [TherapiezielMammaHeilung (Goal)](Goal-TherapiezielMammaHeilung.md)
* [MedicationRequestFOLFOX (MedicationRequest)](MedicationRequest-MedicationRequestFOLFOX.md)
* [MedicationRequestKEYNOTE522 (MedicationRequest)](MedicationRequest-MedicationRequestKEYNOTE522.md)
* [ObsDiseaseStatusMamma (Observation)](Observation-ObsDiseaseStatusMamma.md)
* [ObsEstrogenrezeptorMamma (Observation)](Observation-ObsEstrogenrezeptorMamma.md)
* [ObsGBRCAMamma (Observation)](Observation-ObsGBRCAMamma.md)
* [ObsGradingMamma (Observation)](Observation-ObsGradingMamma.md)
* [ObsHER2Mamma (Observation)](Observation-ObsHER2Mamma.md)
* [ObsHistologieMamma (Observation)](Observation-ObsHistologieMamma.md)
* [ObsKi67Mamma (Observation)](Observation-ObsKi67Mamma.md)
* [ObsProgesteronrezeptorMamma (Observation)](Observation-ObsProgesteronrezeptorMamma.md)
* [ObsTNMklinischMamma (Observation)](Observation-ObsTNMklinischMamma.md)
* [ObsTNMpathologischMamma (Observation)](Observation-ObsTNMpathologischMamma.md)
* [ObservationDiseaseStatusCRC (Observation)](Observation-ObservationDiseaseStatusCRC.md)
* [Onkologisches Zentrum Musterklinik (Organization)](Organization-TumorzentrumCRC.md)
* [Zertifiziertes Brustzentrum Musterklinik (Organization)](Organization-TumorzentrumMamma.md)
* [PatientinCRC (Patient)](Patient-PatientinCRC.md)
* [PatientinMamma (Patient)](Patient-PatientinMamma.md)
* [OnkologinCRC (Practitioner)](Practitioner-OnkologinCRC.md)
* [OnkologinMamma (Practitioner)](Practitioner-OnkologinMamma.md)
* [ProcedureBiopsieMamma (Procedure)](Procedure-ProcedureBiopsieMamma.md)
* [ProcedureOperationMamma (Procedure)](Procedure-ProcedureOperationMamma.md)
* [ServiceRequestBiopsieMamma (ServiceRequest)](ServiceRequest-ServiceRequestBiopsieMamma.md)
* [ServiceRequestGBRCAMamma (ServiceRequest)](ServiceRequest-ServiceRequestGBRCAMamma.md)
* [ServiceRequestKoloskopieCRC (ServiceRequest)](ServiceRequest-ServiceRequestKoloskopieCRC.md)
* [ServiceRequestPathologieMamma (ServiceRequest)](ServiceRequest-ServiceRequestPathologieMamma.md)
* [ServiceRequestPortCRC (ServiceRequest)](ServiceRequest-ServiceRequestPortCRC.md)
* [ServiceRequestProcedure (ServiceRequest)](ServiceRequest-ServiceRequestProcedure.md)
* [ServiceRequestStagingMamma (ServiceRequest)](ServiceRequest-ServiceRequestStagingMamma.md)
* [SpecimenBiopsieMamma (Specimen)](Specimen-SpecimenBiopsieMamma.md)

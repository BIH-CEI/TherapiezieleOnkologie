# de.bih-cei.therapieziele-onkologie#0.1.0: Implementierungsleitfaden Therapieziele Onkologie(de)

## Pages

* [Startseite](index.md)
* [Anwendungsbeispiel (mCRC palliativ)](szenario-krk.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Artefaktübersicht](artifacts.md)
* [Analysebericht (LG-01)](analysebericht.md)

## Resources

### CodeSystems

* [Onkologische Therapieziel-Art](CodeSystem-onko-therapy-goal-type.md)
* [Onkologische Therapieintention](CodeSystem-onko-therapy-intent.md)

### ValueSets

* [Onkologische Therapieziel-Art (VS)](ValueSet-onko-therapy-goal-type.md)
* [Onkologische Therapieintention (VS)](ValueSet-onko-therapy-intent.md)

### Resource Profiles

* [Onkologischer CarePlan](StructureDefinition-onko-care-plan.md)
* [Onkologisches Therapieziel](StructureDefinition-onko-therapy-goal.md)
* [Onkologische Therapielinie](StructureDefinition-onko-therapy-line.md)

### Extensions

* [Onkologische Therapieintention (Extension)](StructureDefinition-onko-therapy-intent.md)

### ImplementationGuides

* [Implementierungsleitfaden Therapieziele Onkologie](ImplementationGuide-bih-cei-therapieziele-onkologie.md)

### Examples

* [CarePlanKRKPalliativ (CarePlan)](CarePlan-CarePlanKRKPalliativ.md)
* [ConditionKRK (Condition)](Condition-ConditionKRK.md)
* [TherapielinieKRKErstlinie (EpisodeOfCare)](EpisodeOfCare-TherapielinieKRKErstlinie.md)
* [TherapiezielKRKLebensverlaengerung (Goal)](Goal-TherapiezielKRKLebensverlaengerung.md)
* [MedicationRequestFOLFOX (MedicationRequest)](MedicationRequest-MedicationRequestFOLFOX.md)
* [ObservationDiseaseStatusKRK (Observation)](Observation-ObservationDiseaseStatusKRK.md)
* [PatientinKRK (Patient)](Patient-PatientinKRK.md)
* [OnkologinKRK (Practitioner)](Practitioner-OnkologinKRK.md)

# de.bih-cei.therapieziele-onkologie#1.0.0-ballot: Implementierungsleitfaden Therapieziele Onkologie(de)

## Pages

* [Startseite](index.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Analysebericht (LG-01)](analysebericht.md)
* [Anwendungsbeispiel (Mammakarzinom neoadjuvant)](szenario-mamma.md)
* [Weitere Entität – Rheumatoide Arthritis](entitaet-rheuma.md)
* [Weitere Entität – Diabetes mellitus](entitaet-diabetes.md)
* [Artefaktübersicht](artifacts.md)
* [Empfehlungs- und Behandlungsplan](empfehlung-behandlung.md)
* [Therapieziele (Goals)](therapieziele.md)
* [Weitere Entität – Asthma bronchiale](entitaet-asthma.md)
* [Weitere Entität – Chronisch-entzündliche Darmerkrankungen](entitaet-ced.md)
* [Anwendungsbeispiel (mCRC palliativ)](szenario-crc.md)
* [Behandlungsepisoden (EpisodeOfCare)](behandlungsepisode.md)
* [Zielwerte und Messgrößen](goal-target-measure.md)
* [Abweichende Szenarios](szenario-mamma-abweichende-szenarios.md)

## Resources

### CodeSystems

* [EnLiST-Änderungstypen](CodeSystem-enlist-change-type.md)
* [EnLiST-Zählstatus](CodeSystem-enlist-countable.md)
* [EnLiST-Setting-Achsen](CodeSystem-enlist-lot-setting.md)
* [Onkologische Therapieziel-Art](CodeSystem-onko-therapy-goal-type.md)

### ValueSets

* [EnLiST-Änderungstypen (ValueSet)](ValueSet-enlist-change-type.md)
* [EnLiST-Zählstatus (ValueSet)](ValueSet-enlist-countable.md)
* [EnLiST-Setting-Achsen (ValueSet)](ValueSet-enlist-lot-setting.md)
* [Onkologische Therapieziel-Art (VS)](ValueSet-onko-therapy-goal-type.md)
* [Onkologische Therapieintention (VS)](ValueSet-onko-therapy-intent.md)
* [Onkologische Therapielinie – Art (VS)](ValueSet-onko-therapy-line-type.md)
* [Onkologische Therapiephase / Unter-Intention (VS)](ValueSet-onko-therapy-phase.md)

### Logicals

* [Therapieziel-Dreieck (logisches Modell)](StructureDefinition-TherapiezielDreieck.md)

### Resource Profiles

* [Onkologischer CarePlan](StructureDefinition-onko-care-plan.md)
* [Onkologische Diagnose (Condition)](StructureDefinition-onko-condition.md)
* [Diagnostischer CarePlan](StructureDefinition-onko-diagnostic-care-plan.md)
* [Onkologisches Therapieziel](StructureDefinition-onko-therapy-goal.md)
* [Onkologische Therapielinie](StructureDefinition-onko-therapy-line.md)
* [Tumorboard MedicationRequest](StructureDefinition-onko-tumorboard-medication-request.md)
* [Tumorboard ServiceRequest](StructureDefinition-onko-tumorboard-service-request.md)

### Extensions

* [EnLiST-Zählstatus (Extension)](StructureDefinition-enlist-countable.md)
* [EnLiST-LoT-Designation (Extension)](StructureDefinition-enlist-lot.md)
* [CarePlan Custodian (Extension)](StructureDefinition-onko-careplan-custodian.md)
* [Onkologische Therapieintention (Extension)](StructureDefinition-onko-therapy-intent.md)
* [Therapielinie – Medikationsverordnung (Extension)](StructureDefinition-onko-therapy-line-medication-request.md)

### ConceptMaps

* [Zielarten → SNOMED CT (Zielzustände)](ConceptMap-ConceptMapOnkoTherapyGoalTypeSct.md)

### ImplementationGuides

* [Implementierungsleitfaden Therapieziele Onkologie](ImplementationGuide-bih-cei-therapieziele-onkologie.md)

### Examples

* [BundleCRCPalliativ (Bundle)](Bundle-BundleCRCPalliativ.md)
* [BundleMammaNeoadjuvant (Bundle)](Bundle-BundleMammaNeoadjuvant.md)
* [CarePlanCRCPalliativ (CarePlan)](CarePlan-CarePlanCRCPalliativ.md)
* [CarePlanMammaDiagnostik (CarePlan)](CarePlan-CarePlanMammaDiagnostik.md)
* [CarePlanMammaNachsorge (CarePlan)](CarePlan-CarePlanMammaNachsorge.md)
* [CarePlanMammaNeoadjuvant (CarePlan)](CarePlan-CarePlanMammaNeoadjuvant.md)
* [DiagnostikCarePlanCRC (CarePlan)](CarePlan-DiagnostikCarePlanCRC.md)
* [Interdisziplinäres Tumorboard Kolorektales Karzinom (CareTeam)](CareTeam-TumorboardCRC.md)
* [ConditionCRC (Condition)](Condition-ConditionCRC.md)
* [ConditionMamma (Condition)](Condition-ConditionMamma.md)
* [DiagnosticReportHistologieCRC (DiagnosticReport)](DiagnosticReport-DiagnosticReportHistologieCRC.md)
* [TherapielinieCRCErstlinie (EpisodeOfCare)](EpisodeOfCare-TherapielinieCRCErstlinie.md)
* [TherapielinieChemo (EpisodeOfCare)](EpisodeOfCare-TherapielinieChemo.md)
* [TherapielinieOperation (EpisodeOfCare)](EpisodeOfCare-TherapielinieOperation.md)
* [TherapieliniePembroAdjuvant (EpisodeOfCare)](EpisodeOfCare-TherapieliniePembroAdjuvant.md)
* [DiagnosticGoal (Goal)](Goal-DiagnosticGoal.md)
* [FollowUpGoal (Goal)](Goal-FollowUpGoal.md)
* [TherapiezielCRCErhaltung (Goal)](Goal-TherapiezielCRCErhaltung.md)
* [TherapiezielCRCKurativAbgelehnt (Goal)](Goal-TherapiezielCRCKurativAbgelehnt.md)
* [TherapiezielCRCLebensverlaengerung (Goal)](Goal-TherapiezielCRCLebensverlaengerung.md)
* [TherapiezielMammaHeilung (Goal)](Goal-TherapiezielMammaHeilung.md)
* [MedicationAdministrationPembroChemoNeoadjuvantMamma1 (MedicationAdministration)](MedicationAdministration-MedicationAdministrationPembroChemoNeoadjuvantMamma1.md)
* [MedicationAdministrationPembroChemoNeoadjuvantMamma2 (MedicationAdministration)](MedicationAdministration-MedicationAdministrationPembroChemoNeoadjuvantMamma2.md)
* [MedicationAdministrationPembroChemoNeoadjuvantMamma3 (MedicationAdministration)](MedicationAdministration-MedicationAdministrationPembroChemoNeoadjuvantMamma3.md)
* [MedicationAdministrationPembroChemoNeoadjuvantMamma4 (MedicationAdministration)](MedicationAdministration-MedicationAdministrationPembroChemoNeoadjuvantMamma4.md)
* [MedicationRequestFOLFOX (MedicationRequest)](MedicationRequest-MedicationRequestFOLFOX.md)
* [MedicationRequestPembroAdjuvantMamma (MedicationRequest)](MedicationRequest-MedicationRequestPembroAdjuvantMamma.md)
* [MedicationRequestPembroChemoNeoadjuvantMamma (MedicationRequest)](MedicationRequest-MedicationRequestPembroChemoNeoadjuvantMamma.md)
* [ObsDiseaseStatusMamma (Observation)](Observation-ObsDiseaseStatusMamma.md)
* [ObsEstrogenrezeptorMamma (Observation)](Observation-ObsEstrogenrezeptorMamma.md)
* [ObsGBRCAMamma (Observation)](Observation-ObsGBRCAMamma.md)
* [ObsGradingMamma (Observation)](Observation-ObsGradingMamma.md)
* [ObsHER2Mamma (Observation)](Observation-ObsHER2Mamma.md)
* [ObsHistologieMamma (Observation)](Observation-ObsHistologieMamma.md)
* [ObsKi67Mamma (Observation)](Observation-ObsKi67Mamma.md)
* [ObsProgesteronrezeptorMamma (Observation)](Observation-ObsProgesteronrezeptorMamma.md)
* [ObsTNMklinischMamma (Observation)](Observation-ObsTNMklinischMamma.md)
* [ObsTNMpathologischMamma (Observation)](Observation-ObsTNMpathologischMamma.md)
* [ObservationDiseaseStatusCRC (Observation)](Observation-ObservationDiseaseStatusCRC.md)
* [Zertifiziertes Brustzentrum Musterklinik (Organization)](Organization-Tumorboard.md)
* [Onkologisches Zentrum Musterklinik (Organization)](Organization-TumorzentrumCRC.md)
* [Zertifiziertes Brustzentrum Musterklinik (Organization)](Organization-TumorzentrumMamma.md)
* [PatientinCRC (Patient)](Patient-PatientinCRC.md)
* [PatientinMamma (Patient)](Patient-PatientinMamma.md)
* [OnkologinCRC (Practitioner)](Practitioner-OnkologinCRC.md)
* [OnkologinMamma (Practitioner)](Practitioner-OnkologinMamma.md)
* [ProcedureBiopsieMamma (Procedure)](Procedure-ProcedureBiopsieMamma.md)
* [ProcedureOperationMamma (Procedure)](Procedure-ProcedureOperationMamma.md)
* [ServiceRequestBiopsieMamma (ServiceRequest)](ServiceRequest-ServiceRequestBiopsieMamma.md)
* [ServiceRequestGBRCAMamma (ServiceRequest)](ServiceRequest-ServiceRequestGBRCAMamma.md)
* [ServiceRequestKoloskopieCRC (ServiceRequest)](ServiceRequest-ServiceRequestKoloskopieCRC.md)
* [ServiceRequestMammographieNachsorge (ServiceRequest)](ServiceRequest-ServiceRequestMammographieNachsorge.md)
* [ServiceRequestPathologieMamma (ServiceRequest)](ServiceRequest-ServiceRequestPathologieMamma.md)
* [ServiceRequestPortCRC (ServiceRequest)](ServiceRequest-ServiceRequestPortCRC.md)
* [ServiceRequestProcedure (ServiceRequest)](ServiceRequest-ServiceRequestProcedure.md)
* [ServiceRequestStagingMamma (ServiceRequest)](ServiceRequest-ServiceRequestStagingMamma.md)
* [SpecimenBiopsieMamma (Specimen)](Specimen-SpecimenBiopsieMamma.md)

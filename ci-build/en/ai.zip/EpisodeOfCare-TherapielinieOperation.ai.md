# Therapielinie 2 – Operation - Implementierungsleitfaden Therapieziele Onkologie v0.1.0

## Example EpisodeOfCare: Therapielinie 2 – Operation

-------

**English**

-------

Profile: [Onkologische Therapielinie](StructureDefinition-onko-therapy-line.md)

> **Onkologische Therapieintention (Extension)**
* hauptintention: Kurativ

**status**: Finished

**type**: Erhaltungstherapie

### Diagnoses

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Condition** | **Role** | **Rank** |
| * | [Condition Bösartige Neubildung: Oberer äußerer Quadrant der Brustdrüse](Condition-ConditionMamma.md) | Chief complaint | 1 |

**patient**: [Sabine Baumann Female, DoB: 1977-06-24](Patient-PatientinMamma.md)

**managingOrganization**: [Organization Zertifiziertes Brustzentrum Musterklinik](Organization-Tumorboard.md)

**period**: 2026-03-20 --> 2026-04-06

**referralRequest**: [ServiceRequest Lumpectomy of breast (procedure)](ServiceRequest-ServiceRequestProcedure.md)

**careManager**: [Practitioner Katrin Musterarzt ](Practitioner-OnkologinMamma.md)



## Resource Content

```json
{
  "resourceType" : "EpisodeOfCare",
  "id" : "TherapielinieOperation",
  "meta" : {
    "profile" : ["https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-line"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "hauptintention",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "373808002",
          "display" : "Kurativ"
        }]
      }
    }],
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent"
  }],
  "status" : "finished",
  "type" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "1345242003",
      "display" : "Erhaltungstherapie"
    }]
  }],
  "diagnosis" : [{
    "condition" : {
      "reference" : "Condition/ConditionMamma"
    },
    "role" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/diagnosis-role",
        "code" : "CC",
        "display" : "Chief complaint"
      }]
    },
    "rank" : 1
  }],
  "patient" : {
    "reference" : "Patient/PatientinMamma"
  },
  "managingOrganization" : {
    "reference" : "Organization/Tumorboard"
  },
  "period" : {
    "start" : "2026-03-20",
    "end" : "2026-04-06"
  },
  "referralRequest" : [{
    "reference" : "ServiceRequest/ServiceRequestProcedure"
  }],
  "careManager" : {
    "reference" : "Practitioner/OnkologinMamma"
  }
}

```

# Therapieziel – Lebensverlängerung & Symptomkontrolle (Beispiel) - Implementierungsleitfaden Therapieziele Onkologie v0.1.0

## Example Goal: Therapieziel – Lebensverlängerung & Symptomkontrolle (Beispiel)

-------

**English**

-------

Profile: [Onkologisches Therapieziel](StructureDefinition-onko-therapy-goal.md)

**Onkologische Therapieintention (Extension)**: Palliativ

**lifecycleStatus**: Active

**achievementStatus**: In Progress

**category**: Lebensverlängerung, Symptomkontrolle / Palliation

**priority**: High Priority

**description**: Verlängerung des Gesamtüberlebens und Kontrolle tumorbedingter Symptome unter palliativer Systemtherapie.

**subject**: [Erika Beispiel Female, DoB: 1958-09-12](Patient-PatientinKRK.md)

**start**: 2026-02-10

### Targets

| | | |
| :--- | :--- | :--- |
| - | **Measure** | **Due[x]** |
| * | Stage group.clinical Cancer | 2026-08-10 |

**expressedBy**: [Practitioner Petra Musterarzt ](Practitioner-OnkologinKRK.md)

**addresses**: [Condition Bösartige Neubildung: Kolon, nicht näher bezeichnet](Condition-ConditionKRK.md)

**outcomeReference**: [Observation Cancer disease status](Observation-ObservationDiseaseStatusKRK.md)



## Resource Content

```json
{
  "resourceType" : "Goal",
  "id" : "TherapiezielKRKLebensverlaengerung",
  "meta" : {
    "profile" : ["https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-goal"]
  },
  "extension" : [{
    "url" : "https://bih-cei.de/fhir/therapieziele-onkologie/StructureDefinition/onko-therapy-intent",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://bih-cei.de/fhir/therapieziele-onkologie/CodeSystem/onko-therapy-intent",
        "code" : "palliativ",
        "display" : "Palliativ"
      }]
    }
  }],
  "lifecycleStatus" : "active",
  "achievementStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/goal-achievement",
      "code" : "in-progress",
      "display" : "In Progress"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "https://bih-cei.de/fhir/therapieziele-onkologie/CodeSystem/onko-therapy-goal-type",
      "code" : "lebensverlaengerung",
      "display" : "Lebensverlängerung"
    }]
  },
  {
    "coding" : [{
      "system" : "https://bih-cei.de/fhir/therapieziele-onkologie/CodeSystem/onko-therapy-goal-type",
      "code" : "symptomkontrolle",
      "display" : "Symptomkontrolle / Palliation"
    }]
  }],
  "priority" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/goal-priority",
      "code" : "high-priority",
      "display" : "High Priority"
    }]
  },
  "description" : {
    "text" : "Verlängerung des Gesamtüberlebens und Kontrolle tumorbedingter Symptome unter palliativer Systemtherapie."
  },
  "subject" : {
    "reference" : "Patient/PatientinKRK"
  },
  "startDate" : "2026-02-10",
  "target" : [{
    "measure" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "21908-9",
        "display" : "Stage group.clinical Cancer"
      }]
    },
    "dueDate" : "2026-08-10"
  }],
  "expressedBy" : {
    "reference" : "Practitioner/OnkologinKRK"
  },
  "addresses" : [{
    "reference" : "Condition/ConditionKRK"
  }],
  "outcomeReference" : [{
    "reference" : "Observation/ObservationDiseaseStatusKRK"
  }]
}

```
